module hw06_James {
	requires martian.manager;
}