package prob1;

public interface Teleporter {
	public String teleport(String dest);
}
